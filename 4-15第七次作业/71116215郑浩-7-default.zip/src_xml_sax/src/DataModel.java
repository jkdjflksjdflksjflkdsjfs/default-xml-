public class DataModel 
{
	public String name;
	public String director;
	public String vocal;
	public String intro;
	public float rating;
	public int series;
}
